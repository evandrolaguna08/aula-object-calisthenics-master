# aula-object-calisthenics
Aplicação das nove regradas de object calisthenics
